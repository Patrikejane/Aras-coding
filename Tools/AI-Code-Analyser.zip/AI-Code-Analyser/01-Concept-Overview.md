# 01 — Concept Overview

## Problem Statement

Aras Innovator customization projects accumulate large amounts of code over time — server methods, client methods, and workflow actions written in C# and JavaScript. These codebases typically suffer from:

- Poor or outdated documentation
- No formal test specifications
- Business logic locked in specific developers heads
- Hard to trace bugs across chained workflows
- Difficult onboarding for new team members
- No clear record of what a method is supposed to do vs what it actually does

## 🔥 In Aras Context (Important)

Aras customizations are tricky because:

- Server methods are event-driven (onBeforeUpdate, etc.)
- Hard to isolate like normal functions
- No built-in unit test framework

## What the Tool Does

The AI Code Analyser reads existing Aras customization code method by method and automatically generates:

- **Preconditions** — what state or data must exist before the method can run correctly
- **Correct Test Patterns** — input scenarios and expected successful outcomes (state changes, process triggers, item updates)
- **Fail Test Patterns** — input scenarios that should be rejected or cause failure, and why

This output is then reviewed and verified by both a Developer and a Business Analyst before being saved as the official specification for that method.

## Why Method by Method

Analyzing one method at a time makes the process manageable, reviewable, incrementally buildable, and correctable — errors in one method spec do not affect others.

## Target Users

| Role | Responsibility |
|------|----------------|
| Developer | Verifies technical correctness of preconditions and patterns |
| Business Analyst | Verifies business rule correctness and process intent |

## Target Codebase

- **Platform:** Aras Innovator
- **Languages:** C# (server methods), JavaScript (client methods, workflow actions)
- **Scope:** Server methods, client methods, workflow actions, lifecycle methods

## Key Insight — The Integration Chain

In Aras, the outcome of one method (a state change or process trigger) becomes the input of another method downstream. This means:

- The Correct output of Method A is the expected input contract of Method B
- Any mismatch between them reveals either a code design issue or an interface/data contract problem in a single Scenario
- This tool makes those contracts explicit and verifiable

## What This Is NOT

- Not a runtime or dynamic analysis tool (static analysis only for this phase)
- Not an automated test runner
- Not a replacement for developer judgment — human verification is required

#concept #aras #genai #overview
