# 05 — Build Roadmap

## Recommended Architecture

### Frontend
- Web-based tool (React or similar)
- Simple UI: paste or upload code, view generated analysis, verify and correct
- Could also be built as a VS Code extension for developer convenience

### Backend
- API that receives code and calls the Claude (Anthropic) API
- Stores verified specs in a database
- Manages method linking for integration chain mapping
- Note: API calls must go through the backend — direct browser-to-API calls are blocked by CORS

### AI Layer
- Claude API (Anthropic) for static analysis
- Well-crafted system prompts specific to Aras patterns:
  - C# server method patterns
  - JavaScript client method patterns
  - Workflow action patterns

## Phased Build Plan

### Phase 1 — Core Tool (Start Here)
- Single method input (paste or upload)
- AI generates preconditions, Correct patterns, Fail patterns
- Developer and BA can review, correct, and approve each item
- Save verified specs per method

Goal: Validate that the AI output quality is good enough to be useful

### Phase 2 — Linking and Chain Mapping
- Connect methods to each other based on input/output contracts
- Show the integration chain visually
- Flag mismatches between method output and downstream method expectations

Goal: Make interface contracts explicit and traceable

### Phase 3 — Knowledge Base
- Searchable library of all analyzed and verified methods
- Filter by project, method type, verification status
- Export specs as documentation

Goal: Living documentation system for the codebase

### Phase 4 — Reporting and Quality
- Integration chain visualization
- Coverage reports showing how much of the codebase has been analyzed
- Code quality flags based on pattern complexity

Goal: Management and governance visibility

## Key Success Factors

- Prompt engineering is critical — AI output quality depends heavily on how well Aras-specific patterns are described in the system prompt
- Start with real methods — validate the concept using 2 to 3 actual methods from a real project before building the full tool
- BA involvement from Day 1 — get business analysts using the tool from Phase 1, not as an afterthought
- Iterative verification — treat the spec as a living document that can be refined over time

## Quick Validation Step (Before Building)

Before writing any code, validate the concept:

1. Take a real Aras C# server method
2. Paste it into Claude with a well-crafted prompt
3. Evaluate the quality of the precondition and Correct/Fail output
4. Have a BA review the output for business correctness

This tells you immediately how viable the approach is and what prompt improvements are needed.

> Validation has been completed for one real method. See [[Validation-Samples/Sample-01-Authorization-Guard]] for the full analysis, verification notes, and outcome.

## Technology Suggestions

| Layer | Suggestion |
|-------|------------|
| Frontend | React + TypeScript |
| Backend | Node.js or Python API |
| AI | Claude API (Anthropic) — claude-sonnet |
| Database | PostgreSQL or SQLite for specs storage |
| Hosting | Internal team server or cloud |

#roadmap #build #architecture #aras #genai
