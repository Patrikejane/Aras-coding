# Prompt 01 — C# Server Method Analysis

## Metadata

- **Version:** 1.0
- **Language target:** C# Aras server method
- **Purpose:** Extract preconditions, Correct patterns, Fail patterns and output contract from a single method
- **Used in:** [[Validation-Samples/Sample-01-Authorization-Guard]]

---

## Prompt

```
You are an Aras Innovator customization expert. Analyse the following C# Aras server method and extract a structured specification.

Return ONLY valid JSON, no explanation, no markdown, no backticks. Format:
{
  "method_purpose": "one sentence description of what this method does",
  "preconditions": [
    { "id": "P1", "description": "..." },
    ...
  ],
  "correct_patterns": [
    { "id": "C1", "input": "...", "expected_output": "..." },
    ...
  ],
  "fail_patterns": [
    { "id": "F1", "input": "...", "expected_output": "..." },
    ...
  ],
  "output_contract": "what this method returns that downstream methods may depend on"
}

Code to analyse:
[paste method code here]
```

---

## Design Decisions

| Decision | Reason |
|----------|--------|
| Domain context first — "Aras Innovator customization expert" | Makes the AI apply platform-specific knowledge such as how `getUserID()`, `getProperty()`, and `newError()` work in the Aras IOM |
| JSON only output — no explanation, no markdown, no backticks | Forces structured parseable output with no extra text that would break JSON parsing in the tool |
| Fixed schema with named fields | Defines exactly the fields needed so the output maps directly to the tool UI sections without post-processing |
| IDs on each item — P1, C1, F1 etc. | Makes each item individually referenceable during the developer and BA verification step |
| `output_contract` as a dedicated field | Specifically captures what downstream methods depend on — the key insight for integration chain mapping |
| Default value fallback in `getProperty` noted | Prompts AI to consider edge cases where properties return empty strings rather than null |

---

## Known Limitations

- Does not yet capture which Aras event or action type triggers this method (lifecycle, workflow, item action)
- Does not ask the AI to identify which ItemType this method is attached to
- Does not prompt for integration chain — which method calls this or what this method calls next
- JS client methods will need a separate prompt variant

---

## Improvement Ideas

- Add a field for `trigger_context` — what Aras event fires this method
- Add a field for `itemtype` — which ItemType this method is attached to
- Add a field for `downstream_dependencies` — what this method's output feeds into
- Create a JS variant of this prompt for client method analysis

---

## Version History

| Version | Change |
|---------|--------|
| 1.0 | Initial prompt used in concept validation session |

---

#prompt #csharp #aras #genai #validation
