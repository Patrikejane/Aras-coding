# Sample 01 — Authorization Guard Method

## Method Details

- **Language:** C# Server Method
- **Platform:** Aras Innovator
- **Type:** Item action / lifecycle server event
- **Validated:** Yes — reviewed in concept validation session

---

## Source Code([[HRDEESMthCheckPICAuthorization.xml]])

```csharp
// Get Innovator instance
Innovator inn = this.getInnovator();
// Get current user ID
string currentUserId = inn.getUserID();
// Get the item being updated
Item item = this;
// Get PIC1 and PIC2 values
string pic1 = item.getProperty("ee_assignee_1", "");
string pic2 = item.getProperty("ee_assignee_2", "");
// Check if current user matches PIC1 or PIC2
bool isAuthorized = (pic1 == currentUserId) || (pic2 == currentUserId);
if (!isAuthorized)
{
    return inn.newError("You are not authorized to update this item. Only PIC1 or PIC2 can perform updates.");
}
// If authorized, allow operation
return item;
```

---

## AI Generated Analysis

Prompt Used : [[Prompt-01-CSharp-Method-Analysis]]
Original Result from Gen AI(Antropic API): [[HRDEESMthCheckPICAuthorization Analyser Result]]

### Method Purpose
Authorization guard that restricts item updates to only the designated PIC1 or PIC2 assignees.

---

### Preconditions

| ID  | Description                                                                                                                          |
| --- | ------------------------------------------------------------------------------------------------------------------------------------ |
| P1  | A valid Aras session must exist with an authenticated user — `inn.getUserID()` must return a non-empty user ID                       |
| P2  | The item being processed (`this`) must be a valid Aras Item object accessible in the current server context                          |
| P3  | The item must have the custom properties `ee_assignee_1` and `ee_assignee_2` defined on its ItemType                                 |
| P4  | The values stored in `ee_assignee_1` and `ee_assignee_2` must be Aras User IDs (GUIDs) matching the format returned by `getUserID()` |

---

### Correct Patterns

| ID  | Input Scenario                                                                                | Expected Output                                           |
| --- | --------------------------------------------------------------------------------------------- | --------------------------------------------------------- |
| C1  | Current user ID matches the value stored in `ee_assignee_1`                                   | Method returns the item — operation is allowed to proceed |
| C2  | Current user ID matches the value stored in `ee_assignee_2`                                   | Method returns the item — operation is allowed to proceed |
| C3  | Current user ID matches both `ee_assignee_1` and `ee_assignee_2` (same user assigned to both) | Method returns the item — operation is allowed to proceed |

---

### Fail Patterns

| ID  | Input Scenario                                                                                     | Expected Output                                                                                                     |
| --- | -------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------- |
| F1  | Current user ID does not match `ee_assignee_1` or `ee_assignee_2`                                  | Returns Aras error: "You are not authorized to update this item. Only PIC1 or PIC2 can perform updates."            |
| F2  | Both `ee_assignee_1` and `ee_assignee_2` are empty strings (no assignees set)                      | Returns error — no user can match an empty string, so all users are blocked from updating                           |
| F3  | `ee_assignee_1` or `ee_assignee_2` contains a display name or login name instead of a User ID GUID | Authorization fails even for the correct user — `getUserID()` returns a GUID and string comparison will never match |

---

### Output Contract

On success returns the current Item (`this`), which can be consumed by downstream lifecycle or workflow methods. On failure returns an Aras error Item that halts the operation and surfaces the error message to the user.

---

## Verification Notes

- **F2 — Open question:** If neither PIC1 nor PIC2 is set, nobody can update the item. Is this intentional by design, or should there be an admin/fallback override?
- **F3 — Data contract risk:** If `ee_assignee_1` or `ee_assignee_2` are ever populated with names instead of GUIDs, authorization silently fails for everyone. Worth checking how those fields are populated upstream.

---

## Validation Outcome

- AI output quality: Good — preconditions and patterns were meaningful and reviewable without needing to rewrite from scratch
- Confirms concept viability for the AI Code Analyser tool

---

#validation #sample #csharp #aras #authorization
