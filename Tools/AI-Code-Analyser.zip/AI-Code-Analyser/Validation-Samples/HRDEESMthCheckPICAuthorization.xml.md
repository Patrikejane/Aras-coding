<AML>
  <Item type="Method" action="add">
    <name>HRDEESMthCheckPICAuthorization</name>
    <method_type>CSharp</method_type>
    <execution_allowed_to>World</execution_allowed_to>
    <is_static>0</is_static>
    <source_code>
		<![CDATA[
		Innovator inn = this.getInnovator();
		
		// Get current user ID
		string currentUserId = inn.getUserID();
		
		// Get current item
		Item item = this;
		
		// Get PIC1 and PIC2
		string pic1 = item.getProperty("pic1", "");
		string pic2 = item.getProperty("pic2", "");
		
		// Check authorization
		if (pic1 != currentUserId && pic2 != currentUserId)
		{
		    return inn.newError("You are not authorized to update this item. Only PIC1 or PIC2 can perform updates.");
		}
		
		return item;
		]]>
    </source_code>
  </Item>
</AML>