# 02 — How It Works

## Tool Flow — Per Method

### Step 1 — Input
Developer pastes or uploads a single C# or JS method into the tool interface.

The tool accepts:
- C# server methods
- JavaScript client methods
- JavaScript workflow action methods
- Lifecycle event methods

### Step 2 — AI Static Analysis
The AI reads the method and generates:

| Output                    | Description                                                                    |
| ------------------------- | ------------------------------------------------------------------------------ |
| **Preconditions**         | What data or state must exist before this method runs                          |
| **Correct Test Patterns** | Inputs and scenarios that should succeed, with expected output/state change    |
| **Fail Test Patterns**    | Inputs and scenarios that should fail, with expected error or rejection reason |
| **Output Contract**       | What this method produces that downstream methods may depend on                |

### Step 3 — Human Verification
Developer and Business Analyst review the generated output together.

Each item is marked as:
- Approved — accepted as-is
- Wrong — corrected with the right information
- Needs Discussion — flagged for further review

### Step 4 — Save and Link
Verified spec is saved against that method and linked to related methods — gradually building the integration chain map across the codebase.

## What the AI Looks For (Static Analysis)

When reading a method the AI identifies:

- Input parameters and their expected types/formats
- Validation checks (if/else, guards, exception throws)
- External data reads (Aras item queries, relationship reads)
- State changes written (property updates, relationship changes, workflow promotions)
- Conditions that cause early exit or failure
- Downstream method calls or process triggers

## Integration Chain Mapping

Since Aras workflows chain methods together:

Method A (Correct Output) feeds into Method B which feeds into Method C.

The tool maps these chains so that the Correct output of one method becomes the expected input spec of the next, and mismatches are flagged as potential design or interface issues.

## Analysis Scope — This Phase

| In Scope | Out of Scope |
|----------|--------------|
| Static code reading | Runtime/dynamic execution |
| C# server methods | Database schema analysis |
| JS client methods | Third-party integrations |
| Workflow action methods | Automated test execution |
| Human-verified specs | Auto-generated test scripts |

#concept #aras #genai #flow #howto
