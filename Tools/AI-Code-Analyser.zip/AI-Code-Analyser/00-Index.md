# AI Code Analyser — Concept Index

> A tool that uses Generative AI to statically analyse Aras customization code and derive preconditions, Correct test patterns, and Fail test patterns — verified by developers and business analysts.

---

## Documents in This Folder

| Note | Description |
|------|-------------|
| [[01-Concept-Overview]] | What the tool is and the problem it solves |
| [[02-How-It-Works]] | Step-by-step flow of the tool |
| [[03-Comparison-with-Traditional-Testing]] | How this differs from unit and integration tests |
| [[04-Expansion-Ideas]] | Future directions and enhancements |
| [[05-Build-Roadmap]] | How to build it incrementally |

---

## Quick Summary

- **Target Codebase:** Aras Innovator customization projects (C# server methods, JS client methods, workflow actions)
- **AI Approach:** Static analysis using Generative AI (Claude API)
- **Verification:** Developer + Business Analyst review and approve output
- **Core Output:** Preconditions, Correct test patterns, Fail test patterns per method
- **Phase:** Concept / Pre-build

---

#concept #aras #genai #testing #tooling
